# Tuto_DrawTrajectory
Tutorial: How to draw a trajectory of player like angry birds (dots path)   / Unity tutorial: https://www.youtube.com/playlist?list=PLMWgYNtBT-xPLmaoYvEw589HcpoPQBLI7

Click on the image to watch the video tutorial:

[![Tutorial](https://img.youtube.com/vi/-F0cYLLdUG8/0.jpg)](https://www.youtube.com/watch?v=-F0cYLLdUG8)


<br><br>
<br>
## ❤️ Donate  
<a href="https://paypal.me/hamzaherbou" title="https://paypal.me/hamzaherbou" target="_blank"><img align="left" height="50" src="https://www.mediafire.com/convkey/72dc/iz78ys7vtfsl957zg.jpg" alt="Paypal"></a>
